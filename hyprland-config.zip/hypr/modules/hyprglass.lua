-- Hyprglass configuration
-- Loaded from hyprland.lua through require("modules.hyprglass").

if not hl.plugin.hyprglass then
    return
end

local hg = hl.plugin.hyprglass

-- ---------------------------------------------------------------------------
-- Global plugin settings
-- ---------------------------------------------------------------------------

hg.config({
    default_theme = "dark",
    default_preset = "golden_gate",
    layers = {
        enabled = true,
    },
})

-- ---------------------------------------------------------------------------
-- Layer surfaces
-- ---------------------------------------------------------------------------

hg.layer("waybar", {
    preset = "subtle",
    mask_threshold = 0.05,
})

hg.layer("swaync")
hg.layer("quickshell:bezel", {
    preset = "ui",
    mask_threshold = 0.3,
})

hg.layer("debug-panel", {
    exclude = true,
})

hg.layer("hyprlauncher", {
    preset = "golden_gate",
    mask_mode = "contour",
    mask_threshold = 0.2,
})

-- ---------------------------------------------------------------------------
-- Main Liquid Glass preset
-- All visual parameters are preserved.
-- ---------------------------------------------------------------------------

hg.preset("golden_gate", {
    inherits = "pomme",

    blur_strength = 1.6,
    blur_iterations = 3,
    noise_strength = 0.04,
    glass_opacity = 2,

    edge_thickness_px = 16,
    edge_height = 14,
    refraction_strength = 0.45,
    chromatic_aberration = 0.15,
    fresnel_strength = 0.35,
    fresnel_reflection = 0.15,
    specular_strength = 0.5,

    bevel_strength = 0.6,
    bevel_size = 2,
    bevel_shadow = 0.25,

    focus_light = 0.5,

    dark = {
        tint_color = 0x16181d38,
        brightness = 0.85,
        contrast = 1.0,
        saturation = 0.9,
        vibrancy = 0.2,
        adaptive_dim = 0.4,
    },

    light = {
        tint_color = 0xf2f4f838,
        brightness = 1.1,
        contrast = 1.0,
        adaptive_boost = 0.3,
    },
})

-- ---------------------------------------------------------------------------
-- Alacritty monochrome preset
-- ---------------------------------------------------------------------------

hg.preset("noir", {
    inherits = "golden_gate",

    noise_strength = 0.10,
    chromatic_aberration = 0.0,

    dark = {
        saturation = 0.0,
        vibrancy = 0.0,
        tint_color = 0x00000050,
        contrast = 1.1,
        brightness = 0.78,
    },

    light = {
        saturation = 0.0,
        vibrancy = 0.0,
    },
})

-- Additional presets retained for optional use.
hg.preset("clear", {
    glass_opacity = 0.8,
    blur_strength = 1.5,
    dark = { brightness = 0.7 },
    light = { brightness = 1.2 },
})

hg.preset("contrasted", {
    inherits = "high_contrast",
    contrast = 1.2,
    adaptive_dim = 1.5,
    dark = {
        tint_color = 0x02142aa9,
    },
})
