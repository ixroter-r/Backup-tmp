-- Hyprland Lua configuration
-- Requires the Lua configuration framework that provides the global `hl` API.

require("modules.hyprglass")
require("modules.keybinds")

-- ---------------------------------------------------------------------------
-- Appearance
-- ---------------------------------------------------------------------------

local RADIUS = 20
local ROUNDING_POWER = 4
local ACTIVE_ALPHA = 0.94
local INACTIVE_ALPHA = 0.86

-- ---------------------------------------------------------------------------
-- Programs
-- ---------------------------------------------------------------------------

-- ---------------------------------------------------------------------------
-- Monitor
-- ---------------------------------------------------------------------------

hl.monitor({
    output = "",
    mode = "1920x1080",
    position = "auto",
    scale = "1.2",
})

-- ---------------------------------------------------------------------------
-- Environment
-- ---------------------------------------------------------------------------

hl.env("XCURSOR_SIZE", "24")
hl.env("HYPRCURSOR_SIZE", "24")

-- ---------------------------------------------------------------------------
-- Core settings
-- All previously separate hl.config() sections are combined here.
-- Visual values and animation settings are intentionally preserved.
-- ---------------------------------------------------------------------------

hl.config({
    general = {
        gaps_in = 5,
        gaps_out = 20,
        border_size = 0,

        col = {
            active_border = "rgba(ffffff44)",
            inactive_border = "rgba(ffffff14)",
        },

        resize_on_border = false,
        allow_tearing = false,
        layout = "dwindle",
    },

    decoration = {
        rounding = RADIUS,
        rounding_power = ROUNDING_POWER,

        active_opacity = ACTIVE_ALPHA,
        inactive_opacity = INACTIVE_ALPHA,
        fullscreen_opacity = 1.0,

        shadow = {
            enabled = true,
            range = 28,
            render_power = 3,
            color = 0x66000000,
            color_inactive = 0x22000000,
        },

        blur = {
            enabled = true,
            size = 4,
            passes = 2,
            vibrancy = 0.1696,
        },
    },

    animations = {
        enabled = true,
    },

    dwindle = {
        preserve_split = true,
    },

    master = {
        new_status = "master",
    },

    scrolling = {
        fullscreen_on_one_column = true,
    },

    misc = {
        force_default_wallpaper = -1,
        disable_hyprland_logo = false,
    },

    layers = {
        allow_new_top_layers_over_existing_fullscreen = true,
    },

    input = {
        kb_layout = "us",
        kb_variant = "",
        kb_model = "",
        kb_options = "",
        kb_rules = "",

        follow_mouse = 1,
        sensitivity = 0,

        touchpad = {
            natural_scroll = false,
        },
    },
})

-- ---------------------------------------------------------------------------
-- Animation curves and timings
-- Values are unchanged to preserve the existing motion and feel.
-- ---------------------------------------------------------------------------

hl.curve("easeOutQuint", {
    type = "bezier",
    points = { { 0.23, 1 }, { 0.32, 1 } },
})

hl.curve("linear", {
    type = "bezier",
    points = { { 0, 0 }, { 1, 1 } },
})

hl.curve("almostLinear", {
    type = "bezier",
    points = { { 0.5, 0.5 }, { 0.75, 1 } },
})

hl.curve("quick", {
    type = "bezier",
    points = { { 0.15, 0 }, { 0.1, 1 } },
})

hl.curve("easy", {
    type = "spring",
    mass = 1,
    stiffness = 238.1191,
    damping = 24.21279333,
})

hl.animation({ leaf = "global",        enabled = true, speed = 10,   bezier = "default" })
hl.animation({ leaf = "border",        enabled = true, speed = 5.39, bezier = "easeOutQuint" })
hl.animation({ leaf = "windows",       enabled = true, speed = 4.79, spring = "easy" })
hl.animation({ leaf = "windowsIn",     enabled = true, speed = 4.1,  spring = "easy",         style = "popin 87%" })
hl.animation({ leaf = "windowsOut",    enabled = true, speed = 1.49, bezier = "linear",       style = "popin 87%" })
hl.animation({ leaf = "fadeIn",        enabled = true, speed = 1.73, bezier = "almostLinear" })
hl.animation({ leaf = "fadeOut",       enabled = true, speed = 1.46, bezier = "almostLinear" })
hl.animation({ leaf = "fade",          enabled = true, speed = 3.03, bezier = "quick" })
hl.animation({ leaf = "layers",        enabled = true, speed = 3.81, bezier = "easeOutQuint" })
hl.animation({ leaf = "layersIn",      enabled = true, speed = 4,    bezier = "easeOutQuint", style = "fade" })
hl.animation({ leaf = "layersOut",     enabled = true, speed = 1.5,  bezier = "linear",       style = "fade" })
hl.animation({ leaf = "fadeLayersIn",  enabled = true, speed = 1.79, bezier = "almostLinear" })
hl.animation({ leaf = "fadeLayersOut", enabled = true, speed = 1.39, bezier = "almostLinear" })
hl.animation({ leaf = "workspaces",    enabled = true, speed = 1.94, bezier = "almostLinear", style = "fade" })
hl.animation({ leaf = "workspacesIn",  enabled = true, speed = 1.21, bezier = "almostLinear", style = "fade" })
hl.animation({ leaf = "workspacesOut", enabled = true, speed = 1.94, bezier = "almostLinear", style = "fade" })
hl.animation({ leaf = "zoomFactor",    enabled = true, speed = 7,    bezier = "quick" })

-- ---------------------------------------------------------------------------
-- Input devices and gestures
-- ---------------------------------------------------------------------------

hl.gesture({
    fingers = 3,
    direction = "horizontal",
    action = "workspace",
})

hl.device({
    name = "epic-mouse-v1",
    sensitivity = -0.5,
})

-- ---------------------------------------------------------------------------
-- Window rules
-- ---------------------------------------------------------------------------

hl.window_rule({
    name = "suppress-maximize-events",
    match = { class = ".*" },
    suppress_event = "maximize",
})

hl.window_rule({
    name = "fix-xwayland-drags",
    match = {
        class = "^$",
        title = "^$",
        xwayland = true,
        float = true,
        fullscreen = false,
        pin = false,
    },
    no_focus = true,
})

hl.window_rule({
    name = "move-hyprland-run",
    match = { class = "hyprland-run" },
    move = "20 monitor_h-120",
    float = true,
})

-- ---------------------------------------------------------------------------
-- Liquid Glass exclusions and per-application appearance
-- ---------------------------------------------------------------------------

-- Fullscreen surfaces do not need glass effects.
hl.window_rule({
    name = "glass-off-fullscreen",
    match = { fullscreen = true },
    tag = "+hyprglass_disabled",
})

-- Games and video players: keep them opaque and avoid blur.
hl.window_rule({
    name = "glass-off-games-video",
    match = { class = "(?i)^(.*sober.*|.*roblox.*|steam_app_.*|mpv|vlc)$" },
    tag = "+hyprglass_disabled",
    opacity = "1.0 override 1.0 override 1.0 override",
    no_blur = true,
})

-- Let terminal applications control their own background transparency.
hl.window_rule({
    name = "terminal-own-opacity",
    match = { class = "(?i)^(alacritty|com\\.mitchellh\\.ghostty|kitty|foot)$" },
    opacity = "1.0 override 1.0 override 1.0 override",
})

hl.window_rule({
    name = "tight-corners-edge-to-edge-apps",
    match = { class = "^org\\.kde\\.dolphin$" },
    rounding = 14,
})

hl.window_rule({
    name = "alacritty-noir-glass",
    match = { class = "(?i)^alacritty$" },
    tag = "+hyprglass_preset_noir",
})

hl.window_rule({
    name = "glass-dolphin",
    match = { class = "^org\\.kde\\.dolphin$" },
    opacity = "0.90 override 0.82 override 1.0 override",
})

hl.window_rule({
    name = "glass-firefox",
    match = { class = "(?i)^(firefox|org\\.mozilla\\.firefox|zen)$" },
    opacity = "0.97 override 0.93 override 1.0 override",
})

-- ---------------------------------------------------------------------------
-- Startup
-- ---------------------------------------------------------------------------

hl.on("hyprland.start", function()
    -- Keep plugin activation and the existing desktop components.
    hl.exec_cmd("hyprpm reload -n")
    hl.exec_cmd("pgrep -x awww-daemon >/dev/null || awww-daemon")
    hl.exec_cmd("quickshell &")
    hl.exec_cmd("qs -c notch")
    hl.exec_cmd("nanonotifyctl autostart")
end)
