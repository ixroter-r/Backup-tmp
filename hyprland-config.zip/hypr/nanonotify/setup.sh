#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
HYPR_DIR="$HOME/.config/hypr"
APP_DIR="$HYPR_DIR/nanonotify"
BIN_DIR="$HOME/.local/bin"
SERVICE_DIR="$HOME/.config/systemd/user"
HYPR_CONF="$HYPR_DIR/hyprland.conf"
MARK_BEGIN='# >>> NanoNotify managed startup >>>'
MARK_END='# <<< NanoNotify managed startup <<<'

if [[ ! -f "$SOURCE_DIR/Makefile" || ! -f "$SOURCE_DIR/src/nanonotify.c" ]]; then
  echo "Run setup.sh from the extracted NanoNotify project directory." >&2
  exit 1
fi

mkdir -p "$HYPR_DIR" "$APP_DIR" "$BIN_DIR" "$SERVICE_DIR"

if ! command -v pacman >/dev/null 2>&1; then
  echo "This installer expects Arch Linux (pacman)." >&2; exit 1
fi

missing=()
for pkg in base-devel pkgconf gtk3 gtk-layer-shell libnotify; do
  pacman -Q "$pkg" >/dev/null 2>&1 || missing+=("$pkg")
done
if ((${#missing[@]})); then
  echo "Missing build/runtime packages: ${missing[*]}"
  read -r -p "Install them with sudo pacman? [Y/n] " answer
  if [[ ! "$answer" =~ ^[Nn]$ ]]; then
    sudo pacman -S --needed "${missing[@]}"
  else
    echo "Cannot build without the required packages." >&2; exit 1
  fi
fi

# Keep a complete local copy of the project and setup scripts under ~/.config/hypr.
cp -a "$SOURCE_DIR/." "$APP_DIR/"

printf '\nBuilding NanoNotify...\n'
make -C "$APP_DIR" clean all
install -Dm755 "$APP_DIR/nanonotify" "$BIN_DIR/nanonotify"
install -Dm755 "$APP_DIR/nanonotifyctl" "$BIN_DIR/nanonotifyctl"
install -Dm644 "$APP_DIR/systemd/nanonotify.service" "$SERVICE_DIR/nanonotify.service"

# Add one idempotent managed block; do not overwrite the user's Hyprland config.
touch "$HYPR_CONF"
if ! grep -Fq "$MARK_BEGIN" "$HYPR_CONF"; then
  cp -n "$HYPR_CONF" "$HYPR_CONF.bak-nanonotify" 2>/dev/null || true
  cat >> "$HYPR_CONF" <<HYPRBLOCK

$MARK_BEGIN
# Import the Wayland session environment before starting NanoNotify.
exec-once = dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP
# Respects the remembered ON/OFF state; 'nanonotifyctl off' stays off after login.
exec-once = ~/.local/bin/nanonotifyctl autostart
$MARK_END
HYPRBLOCK
else
  echo "Hyprland startup block already exists; leaving it unchanged."
fi

systemctl --user daemon-reload
if [[ -n "${WAYLAND_DISPLAY:-}" ]] && command -v dbus-update-activation-environment >/dev/null 2>&1; then
  dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_CURRENT_DESKTOP || true
fi

printf '\nNanoNotify installed.\n'
printf 'Project/config: %s\n' "$APP_DIR"
printf 'Binary:         %s/nanonotify\n' "$BIN_DIR"
printf 'Controller:     %s/nanonotifyctl\n' "$BIN_DIR"
printf '\nStart now? [Y/n] '
read -r answer || answer=''
if [[ ! "$answer" =~ ^[Nn]$ ]]; then
  "$BIN_DIR/nanonotifyctl" on
else
  "$BIN_DIR/nanonotifyctl" off
fi
printf '\nDone. Reload Hyprland (hyprctl reload) or log in again for the startup hook.\n'
printf 'Commands: nanonotifyctl {on|off|toggle|status|logs}\n'
printf 'If command not found, run: export PATH="$HOME/.local/bin:$PATH"\n'
