# NanoNotify 0.1 — automated Hyprland setup

A minimal C/GTK3 + gtk-layer-shell notification daemon for Hyprland.

## Quick install (Arch Linux)

1. Extract the ZIP.
2. In a terminal, `cd` into the extracted `nanonotify` directory.
3. Run:

   ```bash
   ./setup.sh
   ```

The setup script installs missing Arch packages (after asking), builds the C daemon, copies the project to `~/.config/hypr/nanonotify/`, installs the binary and user service, and adds an idempotent startup block to `~/.config/hypr/hyprland.conf`. It creates a backup named `hyprland.conf.bak-nanonotify` if possible.

## Toggle / commands

```bash
nanonotifyctl on       # start now; allow autostart next login
nanonotifyctl off      # stop now; remember OFF and suppress autostart
nanonotifyctl toggle   # switch ON/OFF
nanonotifyctl status   # show ON/OFF
nanonotifyctl restart  # restart only if enabled
nanonotifyctl logs     # recent service logs
```

`off` stops the systemd user service. systemd's `KillMode=control-group` terminates all processes belonging to the service cgroup, not just the main PID. The disabled marker prevents Hyprland's next-login hook from starting it again. `on` removes that marker and starts the service.

## Test

```bash
notify-send "NanoNotify" "It works!"
```

Make sure another notification daemon (Mako, Dunst, SwayNC, etc.) is not already owning `org.freedesktop.Notifications`.

## Uninstall

From the extracted project directory:

```bash
./uninstall.sh
```

This removes NanoNotify's managed Hyprland startup block, service, binaries, and installed project copy. It does not remove dependencies or the user's state directory.

## Notes

- Requires an active Hyprland Wayland session and a user D-Bus session.
- The current daemon displays one notification at a time; new notifications replace the visible one.
- Icons, actions, history, and notification queues are not implemented in v0.1.
- 