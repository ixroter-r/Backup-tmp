#define _GNU_SOURCE
#include <gtk/gtk.h>
#include <gtk-layer-shell.h>
#include <gio/gio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#define BUS_NAME "org.freedesktop.Notifications"
#define OBJECT_PATH "/org/freedesktop/Notifications"
#define INTERFACE_NAME "org.freedesktop.Notifications"
#define DEFAULT_TIMEOUT_MS 5000
#define MAX_TIMEOUT_MS 60000

typedef struct {
    guint32 id;
    GtkWidget *window;
    guint timeout_source;
} Notification;

static GDBusNodeInfo *introspection;
static GDBusConnection *bus_connection;
static guint registration_id;
static guint owner_id;
static GMainLoop *main_loop;
static guint32 next_id = 1;
static Notification *current;

static const gchar introspection_xml[] =
    "<node>"
    " <interface name='org.freedesktop.Notifications'>"
    "  <method name='GetCapabilities'><arg name='capabilities' type='as' direction='out'/></method>"
    "  <method name='Notify'>"
    "   <arg name='app_name' type='s' direction='in'/>"
    "   <arg name='replaces_id' type='u' direction='in'/>"
    "   <arg name='app_icon' type='s' direction='in'/>"
    "   <arg name='summary' type='s' direction='in'/>"
    "   <arg name='body' type='s' direction='in'/>"
    "   <arg name='actions' type='as' direction='in'/>"
    "   <arg name='hints' type='a{sv}' direction='in'/>"
    "   <arg name='expire_timeout' type='i' direction='in'/>"
    "   <arg name='id' type='u' direction='out'/>"
    "  </method>"
    "  <method name='CloseNotification'><arg name='id' type='u' direction='in'/></method>"
    "  <method name='GetServerInformation'>"
    "   <arg name='name' type='s' direction='out'/><arg name='vendor' type='s' direction='out'/>"
    "   <arg name='version' type='s' direction='out'/><arg name='spec_version' type='s' direction='out'/>"
    "  </method>"
    "  <signal name='NotificationClosed'><arg name='id' type='u'/><arg name='reason' type='u'/></signal>"
    "  <signal name='ActionInvoked'><arg name='id' type='u'/><arg name='action_key' type='s'/></signal>"
    " </interface>"
    "</node>";

static void emit_closed(guint32 id, guint32 reason) {
    if (!bus_connection) return;
    g_dbus_connection_emit_signal(bus_connection, NULL, OBJECT_PATH,
        INTERFACE_NAME, "NotificationClosed", g_variant_new("(uu)", id, reason), NULL);
}

static void notification_free(Notification *n) {
    if (!n) return;
    if (n->timeout_source) {
        g_source_remove(n->timeout_source);
        n->timeout_source = 0;
    }
    if (n->window) {
        gtk_widget_destroy(n->window);
        n->window = NULL;
    }
    g_free(n);
}

static void close_current(guint32 reason) {
    if (!current) return;
    guint32 id = current->id;
    Notification *old = current;
    current = NULL;
    notification_free(old);
    emit_closed(id, reason);
}

static gboolean expire_notification(gpointer data) {
    Notification *n = data;
    if (current == n) {
        n->timeout_source = 0;
        close_current(1); /* expired */
    }
    return G_SOURCE_REMOVE;
}

static void close_button_clicked(GtkButton *button, gpointer data) {
    (void)button;
    Notification *n = data;
    if (current == n) close_current(2); /* dismissed by user */
}

static GtkWidget *make_notification_window(const gchar *summary, const gchar *body,
                                           guint8 urgency, Notification *n) {
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);
    gtk_window_set_skip_taskbar_hint(GTK_WINDOW(window), TRUE);
    gtk_window_set_skip_pager_hint(GTK_WINDOW(window), TRUE);
    gtk_window_set_keep_above(GTK_WINDOW(window), TRUE);
    gtk_window_set_accept_focus(GTK_WINDOW(window), FALSE);
    gtk_widget_set_name(window, "nanonotify-window");

    gtk_layer_init_for_window(GTK_WINDOW(window));
    gtk_layer_set_namespace(GTK_WINDOW(window), "nanonotify");
    gtk_layer_set_layer(GTK_WINDOW(window), GTK_LAYER_SHELL_LAYER_OVERLAY);
    gtk_layer_set_anchor(GTK_WINDOW(window), GTK_LAYER_SHELL_EDGE_TOP, TRUE);
    gtk_layer_set_anchor(GTK_WINDOW(window), GTK_LAYER_SHELL_EDGE_RIGHT, TRUE);
    gtk_layer_set_margin(GTK_WINDOW(window), GTK_LAYER_SHELL_EDGE_TOP, 18);
    gtk_layer_set_margin(GTK_WINDOW(window), GTK_LAYER_SHELL_EDGE_RIGHT, 18);
    gtk_layer_set_keyboard_interactivity(GTK_WINDOW(window), FALSE);
    gtk_layer_set_exclusive_zone(GTK_WINDOW(window), -1);

    GtkWidget *outer = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(outer), 14);
    gtk_widget_set_name(outer, urgency >= 2 ? "urgent-card" : "notification-card");

    GtkWidget *text_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_widget_set_hexpand(text_box, TRUE);

    GtkWidget *title = gtk_label_new(NULL);
    gtk_label_set_text(GTK_LABEL(title), summary && *summary ? summary : "Notification");
    gtk_label_set_xalign(GTK_LABEL(title), 0.0f);
    gtk_label_set_line_wrap(GTK_LABEL(title), TRUE);
    gtk_label_set_max_width_chars(GTK_LABEL(title), 48);
    gtk_widget_set_name(title, "notification-title");

    GtkWidget *message = gtk_label_new(NULL);
    gtk_label_set_text(GTK_LABEL(message), body ? body : "");
    gtk_label_set_xalign(GTK_LABEL(message), 0.0f);
    gtk_label_set_line_wrap(GTK_LABEL(message), TRUE);
    gtk_label_set_max_width_chars(GTK_LABEL(message), 58);
    gtk_label_set_selectable(GTK_LABEL(message), TRUE);
    gtk_widget_set_name(message, "notification-body");

    gtk_box_pack_start(GTK_BOX(text_box), title, FALSE, FALSE, 0);
    if (body && *body) gtk_box_pack_start(GTK_BOX(text_box), message, FALSE, FALSE, 0);

    GtkWidget *close = gtk_button_new_with_label("×");
    gtk_widget_set_name(close, "notification-close");
    gtk_widget_set_valign(close, GTK_ALIGN_START);
    g_signal_connect(close, "clicked", G_CALLBACK(close_button_clicked), n);

    gtk_box_pack_start(GTK_BOX(outer), text_box, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(outer), close, FALSE, FALSE, 0);
    gtk_container_add(GTK_CONTAINER(window), outer);
    gtk_widget_show_all(window);
    return window;
}

static void handle_method_call(GDBusConnection *connection, const gchar *sender,
    const gchar *object_path, const gchar *interface_name, const gchar *method_name,
    GVariant *parameters, GDBusMethodInvocation *invocation, gpointer user_data) {
    (void)connection; (void)sender; (void)object_path; (void)interface_name; (void)user_data;

    if (g_str_equal(method_name, "GetCapabilities")) {
        const gchar *caps[] = { "body" };
        g_dbus_method_invocation_return_value(invocation,
            g_variant_new("(^as)", caps));
        return;
    }

    if (g_str_equal(method_name, "GetServerInformation")) {
        g_dbus_method_invocation_return_value(invocation,
            g_variant_new("(ssss)", "NanoNotify", "Community", "0.1", "1.2"));
        return;
    }

    if (g_str_equal(method_name, "CloseNotification")) {
        guint32 id;
        g_variant_get(parameters, "(u)", &id);
        if (current && current->id == id) close_current(3); /* closed by call */
        g_dbus_method_invocation_return_value(invocation, NULL);
        return;
    }

    if (g_str_equal(method_name, "Notify")) {
        const gchar *app_name, *app_icon, *summary, *body;
        guint32 replaces_id;
        GVariant *actions, *hints;
        gint expire_timeout;
        g_variant_get(parameters, "(&su&s&s&s@as@a{sv}i)",
            &app_name, &replaces_id, &app_icon, &summary, &body,
            &actions, &hints, &expire_timeout);
        (void)app_name; (void)app_icon;
        g_variant_unref(actions);

        guint8 urgency = 1;
        g_variant_lookup(hints, "urgency", "y", &urgency);
        g_variant_unref(hints);

        if (current && replaces_id != 0 && current->id == replaces_id) {
            close_current(3);
        } else if (current) {
            close_current(3);
        }

        Notification *n = g_new0(Notification, 1);
        n->id = next_id++;
        if (next_id == 0) next_id = 1;
        current = n;
        n->window = make_notification_window(summary, body, urgency, n);

        gint timeout = expire_timeout;
        if (timeout < 0) timeout = DEFAULT_TIMEOUT_MS;
        if (timeout > MAX_TIMEOUT_MS) timeout = MAX_TIMEOUT_MS;
        if (timeout > 0) n->timeout_source = g_timeout_add((guint)timeout, expire_notification, n);

        g_dbus_method_invocation_return_value(invocation, g_variant_new("(u)", n->id));
        return;
    }

    g_dbus_method_invocation_return_error(invocation, G_DBUS_ERROR,
        G_DBUS_ERROR_UNKNOWN_METHOD, "Unknown method: %s", method_name);
}

static const GDBusInterfaceVTable interface_vtable = {
    .method_call = handle_method_call,
    .get_property = NULL,
    .set_property = NULL
};

static void on_bus_acquired(GDBusConnection *connection, const gchar *name, gpointer user_data) {
    (void)name; (void)user_data;
    bus_connection = connection;
    GError *error = NULL;
    registration_id = g_dbus_connection_register_object(connection, OBJECT_PATH,
        introspection->interfaces[0], &interface_vtable, NULL, NULL, &error);
    if (!registration_id) {
        g_printerr("NanoNotify: cannot register D-Bus object: %s\n", error->message);
        g_error_free(error);
        if (main_loop) g_main_loop_quit(main_loop);
    }
}

static void on_name_acquired(GDBusConnection *connection, const gchar *name, gpointer user_data) {
    (void)connection; (void)user_data;
    g_message("NanoNotify 0.1 is running (D-Bus name: %s)", name);
}

static void on_name_lost(GDBusConnection *connection, const gchar *name, gpointer user_data) {
    (void)connection; (void)user_data;
    g_printerr("NanoNotify: could not acquire %s. Is another notification daemon running?\n", name);
    if (main_loop) g_main_loop_quit(main_loop);
}

int main(int argc, char **argv) {
    gtk_init(&argc, &argv);
    GError *error = NULL;
    introspection = g_dbus_node_info_new_for_xml(introspection_xml, &error);
    if (!introspection) {
        g_printerr("NanoNotify: invalid D-Bus introspection: %s\n", error->message);
        g_error_free(error);
        return EXIT_FAILURE;
    }

    GtkCssProvider *css = gtk_css_provider_new();
    const gchar *css_data =
        "#notification-card, #urgent-card { background: #20232b; color: #eeeeee; "
        "border: 1px solid #414653; border-radius: 12px; }"
        "#urgent-card { border: 1px solid #e0a458; }"
        "#notification-title { color: #ffffff; font-weight: 700; font-size: 14px; }"
        "#notification-body { color: #c9cbd2; font-size: 12px; }"
        "#notification-close { background: transparent; color: #aeb3bf; border: 0; "
        "box-shadow: none; padding: 0 5px; font-size: 18px; }";
    gtk_css_provider_load_from_data(css, css_data, -1, NULL);
    gtk_style_context_add_provider_for_screen(gdk_screen_get_default(),
        GTK_STYLE_PROVIDER(css), GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);
    g_object_unref(css);

    main_loop = g_main_loop_new(NULL, FALSE);
    owner_id = g_bus_own_name(G_BUS_TYPE_SESSION, BUS_NAME, G_BUS_NAME_OWNER_FLAGS_NONE,
        on_bus_acquired, on_name_acquired, on_name_lost, NULL, NULL);
    g_main_loop_run(main_loop);

    close_current(3);
    if (bus_connection && registration_id)
        g_dbus_connection_unregister_object(bus_connection, registration_id);
    if (owner_id) g_bus_unown_name(owner_id);
    g_main_loop_unref(main_loop);
    g_dbus_node_info_unref(introspection);
    return EXIT_SUCCESS;
}
