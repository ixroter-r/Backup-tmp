#!/usr/bin/env bash
set -euo pipefail
BIN_DIR="$HOME/.local/bin"
APP_DIR="$HOME/.config/hypr/nanonotify"
SERVICE_DIR="$HOME/.config/systemd/user"
HYPR_CONF="$HOME/.config/hypr/hyprland.conf"
MARK_BEGIN='# >>> NanoNotify managed startup >>>'
MARK_END='# <<< NanoNotify managed startup <<<'

systemctl --user disable --now nanonotify.service >/dev/null 2>&1 || true
systemctl --user stop nanonotify.service >/dev/null 2>&1 || true
rm -f "$SERVICE_DIR/nanonotify.service" "$BIN_DIR/nanonotify" "$BIN_DIR/nanonotifyctl"
systemctl --user daemon-reload

if [[ -f "$HYPR_CONF" ]] && grep -Fq "$MARK_BEGIN" "$HYPR_CONF"; then
  tmp="$(mktemp)"
  awk -v begin="$MARK_BEGIN" -v end="$MARK_END" '
    $0 == begin { skip=1; next }
    $0 == end { skip=0; next }
    !skip { print }
  ' "$HYPR_CONF" > "$tmp"
  cat "$tmp" > "$HYPR_CONF"
  rm -f "$tmp"
fi
rm -rf "$APP_DIR"
echo "NanoNotify removed. User data/state was left untouched."
