/*
 * launch.c - minimal terminal app launcher. No arguments: just run it.
 *
 * Build:    gcc -Os -static -s -Wl,--gc-sections -o launch launch.c
 *           (if -static fails, drop it; it only trims memory a little further)
 * Install:  sudo install -m755 launch /usr/local/bin/launch
 *
 * Type to filter ("fx" finds Firefox), Up/Down to move, Enter to launch, Esc to quit.
 *
 * Low-resource design: libc only (no ncurses/glib), one line-by-line pass over the
 * .desktop files, one write() per screen frame, apps are started with fork+execvp
 * (no shell, no gio) and the launcher exits right away, so nothing stays resident.
 * The process is short-lived, so memory is deliberately never freed.
 *
 * Sway (needs foot):
 *   for_window [app_id="launcher"] floating enable, resize set 640 360
 *   bindsym --no-warn $mod+d exec foot --app-id launcher -e launch
 */
#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#define QMAX 128                    /* max query length in bytes */
#define WR(s) ((void)!write(1, s, sizeof s - 1))

/* Colors come from the terminal palette, so the UI follows your foot/pywal theme. */
#define C_RESET  "\033[0m"
#define C_BORDER "\033[90m"         /* frame */
#define C_ACCENT "\033[1;36m"       /* title, prompt, selected row */
#define C_SELBG  "\033[100m"        /* selected row background */
#define C_HIT    "\033[1;33m"       /* matched letters */

typedef struct { char *id, *name, *exec, *wd; int term; } App;
typedef struct { int idx, score; } Match;
typedef struct { char *p; size_t len, cap; } Buf;

static App *apps;
static int napps, capapps;
static char **seen;                 /* every desktop ID seen, incl. hidden ones */
static int nseen, capseen;
static const char *prog = "launch";

/* ------------------------------------------------------------ helpers */

static void *xrealloc(void *p, size_t n)
{
    p = realloc(p, n ? n : 1);
    if (!p) { fputs("out of memory\n", stderr); exit(1); }
    return p;
}

static char *xstrdup(const char *s)
{
    size_t n = strlen(s) + 1;
    return memcpy(xrealloc(NULL, n), s, n);
}

static void bput(Buf *b, const char *s, size_t n)
{
    if (b->len + n + 1 > b->cap) {
        b->cap = (b->len + n + 1) * 2;
        b->p = xrealloc(b->p, b->cap);
    }
    memcpy(b->p + b->len, s, n);
    b->len += n;
    b->p[b->len] = 0;
}
static void bputs(Buf *b, const char *s) { bput(b, s, strlen(s)); }
static void bputc(Buf *b, char c) { bput(b, &c, 1); }
static void rep(Buf *b, const char *s, int n) { while (n-- > 0) bputs(b, s); }

static int lc(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }

static int ci_cmp(const char *a, const char *b)
{
    for (;; a++, b++) {
        int x = lc((unsigned char)*a), y = lc((unsigned char)*b);
        if (x != y) return x - y;
        if (!x) return 0;
    }
}

/* ------------------------------------------------------- .desktop parsing */

/* Undo the file-level escapes: \s \n \t \r \\ */
static char *unescape(const char *s)
{
    char *r = xstrdup(s), *w = r;
    for (const char *p = s; *p; p++) {
        if (*p == '\\' && p[1]) {
            char o = 0;
            switch (p[1]) {
            case 's':  o = ' ';  break;
            case 'n':  o = '\n'; break;
            case 't':  o = '\t'; break;
            case 'r':  o = '\r'; break;
            case '\\': o = '\\'; break;
            }
            if (o) { *w++ = o; p++; continue; }
        }
        *w++ = *p;
    }
    *w = 0;
    return r;
}

static void parse_file(const char *path, char *id)
{
    FILE *f = fopen(path, "r");
    if (!f) return;

    char *line = NULL, *name = NULL, *exec = NULL, *wd = NULL;
    size_t cap = 0;
    ssize_t n;
    int in = 0, skip = 0, term = 0;

    while ((n = getline(&line, &cap, f)) > 0) {
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r')) line[--n] = 0;
        if (!line[0] || line[0] == '#') continue;
        if (line[0] == '[') {
            if (in) break;                      /* left [Desktop Entry]: done */
            in = !strcmp(line, "[Desktop Entry]");
            continue;
        }
        if (!in) continue;

        char *eq = strchr(line, '=');
        if (!eq) continue;
        char *val = eq + 1, *ke = eq;
        while (ke > line && ke[-1] == ' ') ke--;
        *ke = 0;
        while (*val == ' ') val++;

        if (!strcmp(line, "Name")) { if (!name) name = unescape(val); }
        else if (!strcmp(line, "Exec")) { if (!exec) exec = unescape(val); }
        else if (!strcmp(line, "Path")) { if (!wd) wd = unescape(val); }
        else if (!strcmp(line, "Terminal")) term = !strcmp(val, "true");
        else if (!strcmp(line, "NoDisplay") || !strcmp(line, "Hidden")) { if (!strcmp(val, "true")) skip = 1; }
        else if (!strcmp(line, "Type")) { if (strcmp(val, "Application")) skip = 1; }
    }
    free(line);
    fclose(f);

    if (skip || !name || !*name || !exec) { free(name); free(exec); free(wd); return; }
    if (napps == capapps) {
        capapps = capapps ? capapps * 2 : 128;
        apps = xrealloc(apps, capapps * sizeof *apps);
    }
    apps[napps++] = (App){ id, name, exec, wd, term };
}

static void scan_dir(const char *dir)
{
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d))) {
        size_t l = strlen(e->d_name);
        if (l <= 8 || strcmp(e->d_name + l - 8, ".desktop")) continue;

        char *id = xrealloc(NULL, l - 7);
        memcpy(id, e->d_name, l - 8);
        id[l - 8] = 0;

        /* Earlier directories win; a hidden user entry also hides the system one */
        int dup = 0;
        for (int i = 0; i < nseen && !dup; i++) dup = !strcmp(seen[i], id);
        if (dup) { free(id); continue; }
        if (nseen == capseen) {
            capseen = capseen ? capseen * 2 : 128;
            seen = xrealloc(seen, capseen * sizeof *seen);
        }
        seen[nseen++] = id;

        char path[4096];
        if (snprintf(path, sizeof path, "%s/%s", dir, e->d_name) < (int)sizeof path)
            parse_file(path, id);
    }
    closedir(d);
}

static void scan_all(void)
{
    const char *home = getenv("HOME"), *xh = getenv("XDG_DATA_HOME"), *xd = getenv("XDG_DATA_DIRS");
    char buf[4096];

    if (xh && *xh) snprintf(buf, sizeof buf, "%s/applications", xh);
    else if (home) snprintf(buf, sizeof buf, "%s/.local/share/applications", home);
    else buf[0] = 0;
    if (buf[0]) scan_dir(buf);

    if (home) {
        snprintf(buf, sizeof buf, "%s/.local/share/flatpak/exports/share/applications", home);
        scan_dir(buf);
    }
    scan_dir("/var/lib/flatpak/exports/share/applications");

    if (!xd || !*xd) xd = "/usr/local/share:/usr/share";
    char *copy = xstrdup(xd);
    for (char *tok = strtok(copy, ":"); tok; tok = strtok(NULL, ":")) {
        snprintf(buf, sizeof buf, "%s/applications", tok);
        scan_dir(buf);
    }
}

/* -------------------------------------------------------------- matching */

/* Lower is better, -1 = no match. needle must already be lowercase.
 * exact < starts-with < contains < letters-in-order ("fx" -> firefox) */
static int score(const char *needle, size_t nl, const char *s)
{
    size_t sl = strlen(s);
    if (nl == 0) return 0;
    if (nl > sl) return -1;

    for (size_t i = 0; i + nl <= sl; i++) {
        size_t k = 0;
        while (k < nl && lc((unsigned char)s[i + k]) == (unsigned char)needle[k]) k++;
        if (k == nl) {
            if (i == 0) return nl == sl ? 0 : 1000 + (int)sl;
            return 2000 + (int)i * 10 + (int)sl;
        }
    }

    size_t j = 0, first = 0, i;
    for (i = 0; i < sl && j < nl; i++)
        if (lc((unsigned char)s[i]) == (unsigned char)needle[j]) {
            if (j == 0) first = i;
            j++;
        }
    if (j == nl) return 3000 + (int)(i - first) * 10 + (int)sl;
    return -1;
}

/* Mark which bytes of s the query matched (same rules as score) so they can be highlighted */
static void hitmask(const char *needle, size_t nl, const char *s, unsigned char *mask, size_t mcap)
{
    size_t sl = strlen(s), i, k, j = 0;
    memset(mask, 0, mcap);
    if (!nl) return;

    for (i = 0; i + nl <= sl; i++) {
        for (k = 0; k < nl && lc((unsigned char)s[i + k]) == (unsigned char)needle[k]; k++) ;
        if (k == nl) {
            for (k = 0; k < nl; k++) if (i + k < mcap) mask[i + k] = 1;
            return;
        }
    }
    for (i = 0; i < sl && j < nl; i++)
        if (lc((unsigned char)s[i]) == (unsigned char)needle[j]) {
            if (i < mcap) mask[i] = 1;
            j++;
        }
    if (j < nl) memset(mask, 0, mcap);          /* not a match in this string */
}

static int match_cmp(const void *x, const void *y)
{
    const Match *a = x, *b = y;
    if (a->score != b->score) return a->score - b->score;
    return ci_cmp(apps[a->idx].name, apps[b->idx].name);
}

/* Fill m (room for napps entries) with ranked matches; empty query = all apps by name */
static int compute(const char *q, Match *m)
{
    char needle[QMAX];
    size_t nl = strlen(q);
    for (size_t i = 0; i <= nl; i++) needle[i] = (char)lc((unsigned char)q[i]);

    int nm = 0;
    for (int i = 0; i < napps; i++) {
        int a = score(needle, nl, apps[i].name), b = score(needle, nl, apps[i].id);
        if (a < 0 || (b >= 0 && b < a)) a = b;
        if (a >= 0) { m[nm].idx = i; m[nm].score = a; nm++; }
    }
    qsort(m, nm, sizeof *m, match_cmp);
    return nm;
}

/* ------------------------------------------------------------- launching */

/* Exec line -> argv, per the Desktop Entry spec: quoting, %% and %c handled,
 * every other field code (%f %F %u %U %i %k ...) expands to nothing. */
static char **build_argv(const App *a)
{
    char **av = NULL;
    int ac = 0, cap = 0;
#define PUSH(s) do { \
        if (ac + 2 > cap) { cap = cap ? cap * 2 : 16; av = xrealloc(av, cap * sizeof *av); } \
        av[ac++] = (s); av[ac] = NULL; } while (0)

    if (a->term) {                              /* Terminal=true: run inside a terminal */
        const char *t = getenv("TERMINAL");
        PUSH(xstrdup(t && *t ? t : "foot"));
        PUSH(xstrdup("-e"));
    }
    int base = ac;

    Buf cur = {0};
    int quoted = 0, have = 0;
    for (const char *s = a->exec;; s++) {
        char c = *s;
        if (!c || (!quoted && (c == ' ' || c == '\t'))) {
            if (cur.len || have) {
                PUSH(xstrdup(cur.p ? cur.p : ""));
                cur.len = 0;
                if (cur.p) cur.p[0] = 0;
                have = 0;
            }
            if (!c) break;
            continue;
        }
        if (c == '"') { quoted = !quoted; have = 1; continue; }
        if (quoted && c == '\\' && s[1] && strchr("\"`$\\", s[1])) { bputc(&cur, *++s); continue; }
        if (c == '%' && s[1]) {
            s++;
            if (*s == '%') bputc(&cur, '%');
            else if (*s == 'c') bput(&cur, a->name, strlen(a->name));
            continue;
        }
        bputc(&cur, c);
    }
    return ac > base ? av : NULL;
#undef PUSH
}

/* Start the app detached from this terminal. Returns 0 on success. A CLOEXEC pipe
 * reports exec failures (e.g. missing binary) back to us, since stdio goes to /dev/null. */
static int launch(const App *a)
{
    char **av = build_argv(a);
    if (!av) { fprintf(stderr, "%s: '%s' has no usable Exec line\n", prog, a->name); return 1; }

    int fd[2];
    if (pipe2(fd, O_CLOEXEC) < 0) { perror("pipe2"); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        setsid();
        int nul = open("/dev/null", O_RDWR);
        if (nul >= 0) {
            dup2(nul, 0); dup2(nul, 1); dup2(nul, 2);
            if (nul > 2) close(nul);
        }
        if (a->wd) (void)!chdir(a->wd);
        execvp(av[0], av);
        int e = errno;
        (void)!write(fd[1], &e, sizeof e);
        _exit(127);
    }
    close(fd[1]);

    int e = 0;
    ssize_t r;
    do { r = read(fd[0], &e, sizeof e); } while (r < 0 && errno == EINTR);
    close(fd[0]);
    if (r == (ssize_t)sizeof e) {
        waitpid(pid, NULL, 0);
        fprintf(stderr, "%s: cannot run '%s': %s\n", prog, av[0], strerror(e));
        return 1;
    }
    return 0;
}

/* ------------------------------------------------------------ terminal I/O */

static struct termios saved_tio;
static volatile sig_atomic_t raw_on, winch;

static void tty_restore(void)
{
    if (!raw_on) return;
    raw_on = 0;
    WR("\033[0 q\033[?7h\033[?1049l");          /* default cursor, autowrap on, leave alt screen */
    tcsetattr(0, TCSAFLUSH, &saved_tio);
}

static void on_fatal(int sig) { tty_restore(); _exit(128 + sig); }
static void on_winch(int sig) { (void)sig; winch = 1; }

static void tty_raw(void)
{
    struct termios t;
    tcgetattr(0, &saved_tio);
    t = saved_tio;
    t.c_iflag &= ~(IXON | ICRNL | INLCR | IGNCR);
    t.c_lflag &= ~(ECHO | ICANON | ISIG | IEXTEN);
    t.c_cc[VMIN] = 1;
    t.c_cc[VTIME] = 0;
    tcsetattr(0, TCSAFLUSH, &t);
    raw_on = 1;
    WR("\033[?1049h\033[?7l\033[5 q");          /* alt screen, autowrap off, blinking bar cursor */

    struct sigaction sa;                        /* no SA_RESTART: resize interrupts read() */
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_winch;
    sigaction(SIGWINCH, &sa, NULL);
    sa.sa_handler = on_fatal;
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);
}

enum { K_NONE = -1, K_EOF = -2, K_INTR = -3 };

/* One byte from stdin. timeout_ms < 0 blocks. */
static int getb(int timeout_ms)
{
    if (timeout_ms >= 0) {
        struct pollfd p = { 0, POLLIN, 0 };
        if (poll(&p, 1, timeout_ms) <= 0) return K_NONE;
    }
    unsigned char c;
    ssize_t r = read(0, &c, 1);
    if (r == 1) return c;
    if (r < 0 && errno == EINTR) return K_INTR;
    return K_EOF;
}

static void write_all(const char *p, size_t n)
{
    while (n) {
        ssize_t w = write(1, p, n);
        if (w < 0) { if (errno == EINTR) continue; return; }
        p += w;
        n -= (size_t)w;
    }
}

/* ---------------------------------------------------------------- drawing */

/* Number of UTF-8 code points in s */
static int cpn(const char *s)
{
    int n = 0;
    for (; *s; s++) n += ((unsigned char)*s & 0xC0) != 0x80;
    return n;
}

/* Longest prefix of s that fits in w columns (counted as UTF-8 code points) */
static size_t clip(const char *s, int w, int *cps)
{
    size_t i = 0;
    int cp = 0;
    if (w < 0) w = 0;
    for (; s[i]; i++)
        if (((unsigned char)s[i] & 0xC0) != 0x80) {
            if (cp == w) break;
            cp++;
        }
    *cps = cp;
    return i;
}

/* Append s[0..nb) switching to `hit` / back to `unhit` around marked characters */
static void put_hl(Buf *o, const char *s, size_t nb, const unsigned char *mask, size_t mcap,
                   const char *hit, const char *unhit)
{
    int on = 0;
    for (size_t i = 0; i < nb;) {
        size_t l = 1;
        while (i + l < nb && ((unsigned char)s[i + l] & 0xC0) == 0x80) l++;
        int h = i < mcap && mask[i];
        if (h != on) { bputs(o, h ? hit : unhit); on = h; }
        bput(o, s + i, l);
        i += l;
    }
    if (on) bputs(o, unhit);
}

/* Draw one frame with a single write(). Returns the number of list rows. */
static int render(const char *q, const Match *m, int nm, int sel, int *top, int full)
{
    struct winsize ws;
    int rows = 24, cols = 80;
    if (ioctl(1, TIOCGWINSZ, &ws) == 0 && ws.ws_row && ws.ws_col) { rows = ws.ws_row; cols = ws.ws_col; }

    static Buf o;
    o.len = 0;
    if (full) bputs(&o, "\033[2J");
    bputs(&o, "\033[H");
    if (rows < 6 || cols < 24) {
        bputs(&o, "\033[2J\033[Hwindow too small");
        write_all(o.p, o.len);
        return 1;
    }

    const int vis = rows - 4, inner = cols - 2, tw = inner - 4;
    if (*top > nm - vis) *top = nm - vis;
    if (*top < 0) *top = 0;
    if (sel < *top) *top = sel;
    if (sel >= *top + vis) *top = sel - vis + 1;

    char needle[QMAX];
    size_t nl = strlen(q);
    for (size_t i = 0; i <= nl; i++) needle[i] = (char)lc((unsigned char)q[i]);

    /* top border with title */
    bputs(&o, C_BORDER "╭─ " C_ACCENT "Apps" C_BORDER " ");
    rep(&o, "─", cols - 9);
    bputs(&o, "╮" C_RESET "\r\n");

    /* prompt line with match counter */
    char cnt[24];
    int cw = snprintf(cnt, sizeof cnt, "%d/%d", nm, napps), qc, qw = inner - 5 - cw;
    if (qw < 1) qw = 1;
    size_t qb = clip(q, qw, &qc);
    bputs(&o, C_BORDER "│" C_RESET " " C_ACCENT "›" C_RESET " ");
    bput(&o, q, qb);
    rep(&o, " ", qw - qc);
    bputs(&o, " \033[2m");
    bputs(&o, cnt);
    bputs(&o, C_RESET " " C_BORDER "│" C_RESET "\r\n");
    const int cur_col = 5 + qc;

    /* separator */
    bputs(&o, C_BORDER "├");
    rep(&o, "─", inner);
    bputs(&o, "┤" C_RESET "\r\n");

    /* list rows (+ scrollbar thumb in the right border when the list overflows) */
    int ts = vis * vis / (nm ? nm : 1);
    if (ts < 1) ts = 1;
    const int tpos = nm > vis ? *top * (vis - ts) / (nm - vis) : 0;

    for (int i = 0; i < vis; i++) {
        int k = *top + i;
        bputs(&o, C_BORDER "│" C_RESET);
        if (k >= nm) {
            const char *msg = (i == 0 && nm == 0) ? (napps ? "no matches" : "no apps found") : "";
            bputs(&o, "   \033[2m");
            bputs(&o, msg);
            bputs(&o, C_RESET);
            rep(&o, " ", inner - 3 - (int)strlen(msg));
        } else {
            const App *a = &apps[m[k].idx];
            const int on = k == sel;
            unsigned char nmask[512], imask[512];
            hitmask(needle, nl, a->name, nmask, sizeof nmask);
            hitmask(needle, nl, a->id, imask, sizeof imask);

            int nc, ic = 0;
            size_t nb = clip(a->name, tw, &nc), ib = 0;
            const int showid = tw - nc > 4;
            if (showid) ib = clip(a->id, tw - nc - 2, &ic);

            bputs(&o, on ? C_SELBG " " C_ACCENT "▌ " : "   ");
            put_hl(&o, a->name, nb, nmask, sizeof nmask, C_HIT, on ? C_ACCENT : "\033[22;39m");
            if (showid) {
                bputs(&o, "\033[22;2;39m  ");
                put_hl(&o, a->id, ib, imask, sizeof imask, "\033[22;33m", "\033[22;2;39m");
                bputs(&o, "\033[22;39m");
            }
            rep(&o, " ", tw - nc - (showid ? 2 + ic : 0) + 1);
            bputs(&o, C_RESET);
        }
        bputs(&o, (nm > vis && i >= tpos && i < tpos + ts) ? C_ACCENT "┃" : C_BORDER "│");
        bputs(&o, C_RESET "\r\n");
    }

    /* bottom border with key hints */
    const char *hint = " ↑↓ move · enter launch · esc quit ";
    int fill = cols - 3 - cpn(hint);
    if (fill >= 0) {
        bputs(&o, C_BORDER "╰─" C_RESET "\033[2m");
        bputs(&o, hint);
        bputs(&o, C_RESET C_BORDER);
        rep(&o, "─", fill);
    } else {
        bputs(&o, C_BORDER "╰");
        rep(&o, "─", cols - 2);
    }
    bputs(&o, "╯" C_RESET);

    char tmp[32];
    snprintf(tmp, sizeof tmp, "\033[2;%dH", cur_col);
    bputs(&o, tmp);
    write_all(o.p, o.len);
    return vis;
}

/* ----------------------------------------------------------------- picker */

/* Returns the chosen app index, or -1 if cancelled */
static int pick(void)
{
    Match *m = xrealloc(NULL, ((size_t)napps + 1) * sizeof *m);
    char q[QMAX] = "";
    size_t ql = 0;
    int nm = compute(q, m), sel = 0, top = 0, vis = 10, result = -1, full = 1;

    tty_raw();
    for (;;) {
        struct pollfd p = { 0, POLLIN, 0 };
        if (winch || full || poll(&p, 1, 0) <= 0) {     /* skip drawing while input is queued */
            if (winch) full = 1;
            winch = 0;
            vis = render(q, m, nm, sel, &top, full);
            full = 0;
        }
        int c = getb(-1), dirty = 0;
        if (c == K_INTR) continue;
        if (c < 0) break;

        if (c == 0x1b) {
            int c2 = getb(50);
            if (c2 == K_NONE) break;                    /* lone Esc = cancel */
            if (c2 == '[' || c2 == 'O') {               /* arrow / page keys */
                int param = 0, f;
                while ((f = getb(50)) >= 0 && (f < 0x40 || f > 0x7e))
                    if (!param) param = f;
                if (f == 'A') sel--;
                else if (f == 'B') sel++;
                else if (f == '~' && param == '5') sel -= vis;
                else if (f == '~' && param == '6') sel += vis;
            }
        }
        else if (c == '\r' || c == '\n') { if (nm > 0) { result = m[sel].idx; break; } }
        else if (c == 0x03 || c == 0x04) break;                         /* Ctrl-C / Ctrl-D */
        else if (c == 0x0e || c == '\t') sel++;                         /* Ctrl-N, Tab */
        else if (c == 0x10) sel--;                                      /* Ctrl-P */
        else if (c == 0x7f || c == 0x08) {                              /* Backspace (UTF-8 aware) */
            if (ql) {
                do ql--; while (ql && ((unsigned char)q[ql] & 0xC0) == 0x80);
                q[ql] = 0;
                dirty = 1;
            }
        }
        else if (c == 0x15) { ql = 0; q[0] = 0; dirty = 1; }            /* Ctrl-U */
        else if (c == 0x17) {                                           /* Ctrl-W */
            while (ql && q[ql - 1] == ' ') ql--;
            while (ql && q[ql - 1] != ' ') ql--;
            q[ql] = 0;
            dirty = 1;
        }
        else if (c >= 0x20 && ql < sizeof q - 1) { q[ql++] = (char)c; q[ql] = 0; dirty = 1; }

        if (dirty) { nm = compute(q, m); sel = top = 0; }
        if (sel > nm - 1) sel = nm - 1;
        if (sel < 0) sel = 0;
    }
    tty_restore();
    return result;
}

int main(void)
{
    if (!isatty(0) || !isatty(1)) {
        fprintf(stderr, "%s: run me in a terminal\n", prog);
        return 1;
    }
    scan_all();
    int i = pick();
    if (i < 0) return 1;                        /* cancelled */
    if (launch(&apps[i])) {                     /* keep the error visible before the window closes */
        fputs("Press Enter to close...", stderr);
        getchar();
        return 1;
    }
    return 0;
}

